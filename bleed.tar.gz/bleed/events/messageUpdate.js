const client = require('../bleed')

client.on('messageUpdate', (oldMessage, newMessage) => {
  if (!oldMessage || !newMessage) return;
  if (oldMessage.partial) return;
  if (!oldMessage.author || oldMessage.author.bot) return;
  if (oldMessage.content === newMessage.content) return;

  client.messageUpdate.set(oldMessage.channel.id, {
    content: oldMessage.content,
    author: oldMessage.author.tag,
    image: oldMessage.attachments.first() ? oldMessage.attachments.first().proxyURL : null
  });
});
