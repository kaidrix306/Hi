const client = require('../bleed')

client.on("ready", () => {
  console.log(`\n✅ ${client.user.username} is now up and running!`);
  console.log(`🤖 Bot ID: ${client.user.id}`);
  console.log(`🔗 Invite Link: https://discord.com/api/oauth2/authorize?client_id=${client.user.id}&permissions=8&scope=bot\n`);
  client.user.setActivity(`discord.gg/four`, {
    type: "PLAYING",
    url: "https://www.twitch.tv/discord"
  })
})
