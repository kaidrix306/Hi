const { readdirSync } = require("fs");

module.exports = (client) => {
  const files = readdirSync("./events/").filter(file => file.endsWith(".js"));
  for (const file of files) {
    require(`../events/${file}`);
  }
}
