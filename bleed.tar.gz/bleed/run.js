#!/usr/bin/env node
/**
 * run.js — Bleed bot launcher
 * Installs dependencies then starts the bot.
 * Usage: node run.js
 */

const { execSync, spawn } = require('child_process');
const path = require('path');
const fs = require('fs');

const projectDir = __dirname;

console.log('=================================================');
console.log('           Bleed Bot — Launcher');
console.log('=================================================\n');

// ── 1. Install dependencies ──────────────────────────────
console.log('📦 Installing dependencies (this may take a minute)...\n');
try {
  execSync('npm install', {
    cwd: projectDir,
    stdio: 'inherit'
  });
  console.log('\n✅ Dependencies installed.\n');
} catch (err) {
  console.error('❌ npm install failed:', err.message);
  process.exit(1);
}

// ── 2. Start the bot ─────────────────────────────────────
console.log('🚀 Starting the bot...\n');

const bot = spawn('node', ['bleed.js'], {
  cwd: projectDir,
  stdio: 'inherit',
  env: process.env
});

bot.on('error', (err) => {
  console.error('❌ Failed to start bot:', err.message);
  process.exit(1);
});

bot.on('exit', (code) => {
  if (code !== 0) {
    console.error(`\n❌ Bot exited with code ${code}`);
    process.exit(code);
  }
});

process.on('SIGINT', () => {
  console.log('\n🛑 Shutting down...');
  bot.kill('SIGINT');
});

process.on('SIGTERM', () => {
  bot.kill('SIGTERM');
});
